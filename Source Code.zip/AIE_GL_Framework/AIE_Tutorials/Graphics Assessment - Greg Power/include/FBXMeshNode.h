#ifndef _FBXMESHNODE_H_
#define _FBXMESHNODE_H_

class FBXMeshNode
{
public:

private:

};

#endif